<?php
include 'conn.php'; 
session_start(); 
if (!isset($_SESSION['user_id'])) {
 
    header("Location: index.php"); 
    exit();
}

if (isset($_GET['action']) && $_GET['action'] === 'fetch_users') {
    header('Content-Type: application/json');

    $sql = "SELECT * FROM users"; 
    $result = $conn->query($sql);

    $users = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
    }

    echo json_encode(['data' => $users]);

    $conn->close();
    exit(); 
}

// Handle AJAX request to add a new user
if (isset($_POST['action']) && $_POST['action'] === 'add_user') {
    header('Content-Type: application/json');

    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);

    // Prepare and execute the SQL statement
    $sql = "INSERT INTO users (name, email) VALUES ('$name', '$email')";
    $success = $conn->query($sql);

    if ($success) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => $conn->error]);
    }

    $conn->close();
    exit(); 
}

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['logout'])) {

    session_unset(); 
    session_destroy(); 
    header("Location: index.php"); 
    exit;
}




// Handle AJAX request to update a user
if (isset($_POST['action']) && $_POST['action'] === 'update_user') {
    header('Content-Type: application/json');

    $id = intval($_POST['userId']);
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);

    // Prepare and execute the SQL statement
    $sql = "UPDATE users SET name='$name', email='$email' WHERE id=$id";
    $success = $conn->query($sql);

    if ($success) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => $conn->error]);
    }

    $conn->close();
    exit(); 
}

// Handle AJAX request to delete a user
if (isset($_POST['action']) && $_POST['action'] === 'delete_user') {
    header('Content-Type: application/json');

    $id = intval($_POST['id']);

    // Prepare and execute the SQL statement
    $sql = "DELETE FROM users WHERE id=$id";
    $success = $conn->query($sql);

    if ($success) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => $conn->error]);
    }

    $conn->close();
    exit(); 
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/datatable.css">
    <link rel="stylesheet" href="assets/css/comm_style.css">
    <script src="assets/js/datatable.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
</head>

<body>

    <div class="container">
        <br>
        <button class="btn btn-warning" id="showFormBtn">Add New User</button>
        <br>
        <br>
        <form method="post" action="">
            <button type="submit" name="logout" class="btn btn-danger">logout</button>
        </form>


        <!-- Alert Container -->
        <div id="alertContainer" class="container mt-3">
            <div id="alertMessage" class="alert" role="alert" style="display: none;"></div>
        </div>
        <!-- Add/Edit User Form -->
        <div class="center-container" id="add_new_user" style="display: none;">
            <form id="userForm" class="bordered-form">
                <h3 style="text-align:center">Insert New User</h3>
                <input type="hidden" id="userId" name="userId">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" class="form-control" required><br><br>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" class="form-control" required><br><br>
                <button type="submit" class="btn btn-success" id="submitBtn">Add</button>
                <button type="button" class="btn btn-secondary" id="cancelBtn">Cancel</button>
            </form>
        </div>
        <br>

        <h3>Users List</h3>
        <table id="userTable" class="border display">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>

    <script>
    $(document).ready(function() {
        var table = $('#userTable').DataTable({
            "ajax": {
                "url": "?action=fetch_users",
                "type": "GET",
                "dataSrc": "data"
            },
            "columns": [{
                    "data": "id"
                },
                {
                    "data": "name"
                },
                {
                    "data": "email"
                },
                {
                    "data": null,
                    "defaultContent": '<button class="btn btn-info btn-edit">Edit</button> <button class="btn btn-danger btn-delete">Delete</button>'
                }
            ]
        });

        // Show form for adding new user
        $('#showFormBtn').click(function() {
            $('#userForm')[0].reset();
            $('#userId').val('');
            $('#submitBtn').text('Add');
            $('#add_new_user').show();
        });

        // Cancel form
        $('#cancelBtn').click(function() {
            $('#add_new_user').hide();
        });

        // Form submission for add/update
        $('#userForm').submit(function(e) {
            e.preventDefault();
            var formData = $(this).serialize();
            var action = $('#userId').val() ? 'update_user' : 'add_user';
            formData += '&action=' + action;

            $.ajax({
                url: '',
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.status === 'success') {
                        showAlert('Success',
                            'User has been added/updated successfully.', 'success');
                        $('#add_new_user').hide();
                        table.ajax.reload();
                    } else {
                        showAlert('Error', response.message, 'danger');
                    }
                },
                error: function() {
                    showAlert('Error', 'An unexpected error occurred.', 'danger');
                }
            });
        });

        // Edit user
        $('#userTable').on('click', '.btn-edit', function() {
            var data = table.row($(this).parents('tr')).data();
            $('#name').val(data.name);
            $('#email').val(data.email);
            $('#userId').val(data.id);
            $('#submitBtn').text('Update');
            $('#add_new_user').show();
        });

        // Delete user
        $('#userTable').on('click', '.btn-delete', function() {
            var data = table.row($(this).parents('tr')).data();
            if (confirm('Are you sure you want to delete this user?')) {
                $.ajax({
                    url: '',
                    type: 'POST',
                    data: {
                        action: 'delete_user',
                        id: data.id
                    },
                    success: function(response) {
                        if (response.status === 'success') {
                            showAlert('Success', 'User has been deleted successfully.',
                                'success');
                            table.ajax.reload();
                        } else {
                            showAlert('Error', response.message, 'danger');
                        }
                    },
                    error: function() {
                        showAlert('Error', 'An unexpected error occurred.', 'danger');
                    }
                });
            }
        });

        function showAlert(title, message, type) {
            var alertMessage = $('#alertMessage');
            alertMessage.removeClass('alert-success alert-danger');
            alertMessage.addClass('alert-' + type);
            alertMessage.html('<strong>' + title + '</strong> ' + message);
            alertMessage.show();
            setTimeout(function() {
                alertMessage.hide();
            }, 2000);
        }
    });
    </script>
</body>

</html>