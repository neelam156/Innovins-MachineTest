<?php

include 'conn.php';
session_start(); 
if (isset($_SESSION['user_id'])) {
 
    header("Location: list.php"); 
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare the SQL statement to avoid SQL injection
    $stmt = $conn->prepare("INSERT INTO register_user (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $hashed_password);

    try {
        // Execute the statement
        $stmt->execute();
        $_SESSION['alert_message'] = '<div class="alert alert-success" role="alert">New User Register successfully!</div>';
    } catch (mysqli_sql_exception $e) {
      
        if ($e->getCode() == 1062) { 
            $_SESSION['alert_message'] = '<div class="alert alert-danger" role="alert">Error: Email is already registered.</div>';
        } else {
            $_SESSION['alert_message'] = '<div class="alert alert-danger" role="alert">Error: ' . $e->getMessage() . '</div>';
        }
    }

    $stmt->close();
    $conn->close();
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
   
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);

    $stmt = $conn->prepare("SELECT id, name, password FROM register_user WHERE email = ?");
    $stmt->bind_param("s", $email);

    try {
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];

              
                header("Location: list.php");
                exit;
            } else {
                $_SESSION['login_message'] = '<div class="alert alert-danger" role="alert">Invalid email or password.</div>';
            }
        } else {
            $_SESSION['login_message'] = '<div class="alert alert-danger" role="alert">Invalid email or password.</div>';
        }
    } catch (mysqli_sql_exception $e) {
        $_SESSION['login_message'] = '<div class="alert alert-danger" role="alert">Error: ' . $e->getMessage() . '</div>';
    }
    // Close the statement
    $stmt->close();

    // Close the connection
    $conn->close();

    // Redirect back to the login page
    header("Location: list.php");
    exit;
}




?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login & Registration</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/comm_style.css">
    <style>
    .form-container {
        display: none;
    }

    .log-reg-forms {
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .bordered-form {
        border: 1px solid #ddd;
        border-radius: 5px;
        padding: 20px;
        width: 100%;
        max-width: 400px;
        /* Maximum width of the form */
    }
    </style>
</head>

<body>
    <!-- Header with Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">MyApp</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#" id="showLogin">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" id="showRegistration">Register</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4 ">

        <div class="message-alert">
            <?php
                if (isset($_SESSION['alert_message'])) {
                    echo $_SESSION['alert_message'];
                    unset($_SESSION['alert_message']); // Clear the message after displaying it
                }
                ?>
        </div>

        <div class="row log-reg-forms">


            <div class="form-container bordered-form" id="loginForm" style="display:block">

                <?php
  if (isset($_SESSION['login_message'])) {
    echo $_SESSION['login_message'];
    unset($_SESSION['login_message']); 
}
            ?>
                <h2>Login</h2>
                <form method="post" action="">
                    <div class="form-group">
                        <label for="loginEmail">Email address</label>
                        <input type="email" class="form-control" id="loginEmail" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="loginPassword">Password</label>
                        <input type="password" class="form-control" id="loginPassword" name="password" required>
                    </div>
                    <button type="submit" name="login" class="btn btn-primary">Login</button><br><br>

                    <a class="nav-link" href="forget-password.php" id="forget_pass_link">Forgot Password</a>
                </form>
            </div>


            <div class="form-container bordered-form" id="forget-pass" style="display:none">

                <h2>Forgot Password</h2>
                <form method="post" action="forget-password-process.php">
                    <div class="form-group">
                        <label for="email">Enter your email address:</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <input type="submit" name="forget-pass" class="btn btn-primary"></input>
                </form>



            </div>

            <!-- Registration Form -->
            <div class="form-container bordered-form" id="registrationForm">
                <h2>Register</h2>
                <!-- Display any alert message here -->
                <?php
                

                if (isset($_SESSION['alert_message'])) {
                    echo $_SESSION['alert_message'];
                    unset($_SESSION['alert_message']); 
                }
                ?>
                <form method="post" action="">
                    <div class="form-group">
                        <label for="registerName">Name</label>
                        <input type="text" class="form-control" id="registerName" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="registerEmail">Email address</label>
                        <input type="email" class="form-control" id="registerEmail" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="registerPassword">Password</label>
                        <input type="password" class="form-control" id="registerPassword" name="password" required>
                    </div>
                    <button type="submit" name="register" class="btn btn-primary">Register</button>
                </form>
            </div>
        </div>
    </div>

    <!-- jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#showLogin').on('click', function(e) {
            e.preventDefault();
            $('#loginForm').show();
            $('#registrationForm').hide();
        });

        $('#showRegistration').on('click', function(e) {
            e.preventDefault();
            $('#loginForm').hide();
            $('#registrationForm').show();
        });


    });
    </script>
</body>

</html>