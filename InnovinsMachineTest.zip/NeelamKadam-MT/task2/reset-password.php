<?php
session_start();
include 'conn.php'; 
include 'head.php'; 
if (!isset($_SESSION['reset_email']) || !isset($_SESSION['verification_code'])) {
    header("Location: forget-password.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reset_password'])) {
    $new_password = $_POST['password'];
    $email = $_SESSION['reset_email'];

    if (strlen($new_password) < 3) {
        $_SESSION['message'] = '<div class="alert alert-danger" role="alert">Password must be at least 6 characters long.</div>';
    } else {
        
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

      
        $stmt = $conn->prepare("UPDATE register_user SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $hashed_password, $email);

        if ($stmt->execute()) {
            $_SESSION['message'] = '<div class="alert alert-success" role="alert">Password has been reset successfully.</div>';
            unset($_SESSION['reset_email']);
            unset($_SESSION['verification_code']);
            header("Location: index.php"); 
            exit;
        } else {
            $_SESSION['message'] = '<div class="alert alert-danger" role="alert">Error updating password: ' . $conn->error . '</div>';
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<body>
    <div class="container mt-5">
        <div class="center-container">


            <div class="form-container bordered-form ">
                <?php
if (isset($_SESSION['message'])) {
echo $_SESSION['message'];
unset($_SESSION['message']);
}
?>
                <h2>Reset Password</h2>
                <form method="post" action="">
                    <div class="form-group">
                        <label for="password">Enter New Password:</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <input type="submit" name="reset_password" class="btn btn-primary" value="Reset Password">
                </form>
            </div>
        </div>
    </div>
</body>

</html>