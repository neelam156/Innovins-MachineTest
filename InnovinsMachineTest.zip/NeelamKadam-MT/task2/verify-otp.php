<?php
session_start();
include 'conn.php'; 
include 'head.php'; 

if (!isset($_SESSION['reset_email']) || !isset($_SESSION['verification_code'])) {
    header("Location: forget-password.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['verify'])) {
    $entered_otp = $_POST['otp'];

    if ($entered_otp === $_SESSION['verification_code']) {
        $_SESSION['message'] = '<div class="alert alert-success" role="alert">OTP Verified. You can now reset your password.</div>';
        header("Location: reset-password.php"); // Redirect to reset password page
        exit;
    } else {
        $_SESSION['message'] = '<div class="alert alert-danger" role="alert">Invalid OTP.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">



<body>
    <div class="container mt-5">
        <div class="center-container">


            <div class="form-container bordered-form ">
                <?php
        if (isset($_SESSION['message'])) {
            echo $_SESSION['message'];
            unset($_SESSION['message']);
        }
        ?>
                <h2>Verify OTP</h2>
                <form method="post" action="">
                    <div class="form-group">
                        <label for="otp">Enter OTP:</label>
                        <input type="text" class="form-control" id="otp" name="otp" required>
                    </div>
                    <input type="submit" name="verify" class="btn btn-primary" value="Verify OTP">
                </form>
            </div>
        </div>
    </div>
</body>

</html>