<?php
session_start();
include 'conn.php'; 
include 'head.php'; 

// Simulated OTP (in a real application, this should be dynamically generated and securely stored)
define('OTP_VERIFICATION_CODE', '1111');

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['forget-pass'])) {
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);

    if (!$email) {
        $_SESSION['message'] = '<div class="alert alert-danger" role="alert">Invalid email address.</div>';
    } else {
        // Check if email exists in the register_user table
        $stmt = $conn->prepare("SELECT COUNT(*) FROM register_user WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($email_count);
        $stmt->fetch();
        $stmt->close();

        if ($email_count == 0) {
            $_SESSION['message'] = '<div class="alert alert-danger" role="alert">Email address not found.</div>';
        } else {
            // Email exists, set session data for OTP verification
            $_SESSION['reset_email'] = $email;
            $_SESSION['verification_code'] = OTP_VERIFICATION_CODE;

            // Redirect to OTP verification page
            header("Location: verify-otp.php");
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">


<body>
    <div class="container mt-5">

        <div class="center-container">

            <?php
        if (isset($_SESSION['message'])) {
            echo $_SESSION['message'];
            unset($_SESSION['message']);
        }
        ?>
            <div class="form-container bordered-form ">
                <h2>Forgot Password</h2>
                <form method="post" action="">
                    <div class="form-group">
                        <label for="email">Enter your email address:</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <input type="submit" name="forget-pass" class="btn btn-primary" name="submit">
                </form>
            </div>
        </div>
    </div>
</body>

</html>