<?php

$servername = "localhost"; 
$username = "root";        
$password = "";           
$dbname = "kadamneelam_db";  

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}






// API endpoint for add new product

if ($_SERVER['REQUEST_METHOD'] == 'POST' ) {

    if (isset($_POST['action']) &&  $_POST['action'] == 'add') {

        if (isset($_POST['product_name']) && isset($_POST['product_price']) && isset($_POST['product_qty'])&& isset($_POST['product_desc'])) {
            $name = $conn->real_escape_string($_POST['product_name']);
            $price = $conn->real_escape_string($_POST['product_price']);
            $qty = $conn->real_escape_string($_POST['product_qty']);
            $description = $conn->real_escape_string($_POST['product_desc']);
            
            $sql = "INSERT INTO products (product_name, product_price, product_qty,product_desc) VALUES ('$name', '$price', '$qty','$description')";
            
            if ($conn->query($sql) === TRUE) {
                echo json_encode(["success" => "Product added successfully"]);
            } else {
                echo json_encode(["error" => "Error adding product: " . $conn->error]);
            }
        } else {
            echo json_encode(["error" => "Invalid input data"]);
        }
    }
   
      
}
// API endpoint for list all product

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action']) &&  $_POST['action'] == 'list') {
        $sql = "SELECT * FROM products";
        $result = $conn->query($sql);
        $products = array();
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $products[] = $row;
            }
        }
        echo json_encode($products);
    }
      
}

// API endpoint for display specific product

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action']) &&  $_POST['action'] == 'fetch') {

        $productId = intval($_POST['id']); 
        $sql = "SELECT * FROM products WHERE id = $productId";
        
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $product = $result->fetch_assoc();
            echo json_encode($product);
        } else {
            echo json_encode(["error" => "Product not found"]);
        }
        echo json_encode($products);
        }
}



// API endpoint for update specific product

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action']) &&  $_POST['action'] == 'update') {
     $id = isset($_POST['id']) ? intval($_POST['id']) : '';
     $product_name = isset($_POST['product_name']) ? $_POST['product_name'] : '';
     $product_qty = isset($_POST['product_qty']) ? $_POST['product_qty'] : '';
     $product_price = isset($_POST['product_price']) ? $_POST['product_price'] : '';
     $product_desc = isset($_POST['product_desc']) ? $_POST['product_desc'] : '';
     
     // Prepare the SQL update query
     $sql = "UPDATE products SET product_name = ?, product_qty = ? , product_price = ? , product_desc = ? WHERE id = ?";
     $stmt = $conn->prepare($sql);
     $stmt->bind_param('siisi', $product_name, $product_qty, $product_price, $product_desc, $id);
     
     if ($stmt->execute()) {
         echo json_encode(["message" => "Record updated successfully"]);
     } else {
         echo json_encode(["message" => "Failed to update record"]);}
     }
    }



    
if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
   
 $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    
        $sql = "DELETE FROM products WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $id);
     
        if ($stmt->execute()) {
            echo json_encode(["message" => "Record deleted successfully"]);
        } 
       

    
}